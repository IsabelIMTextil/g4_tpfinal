<div class=" mt-2 border-0">
 
  <table class="table">
  
 
  <tbody>

  <!--<div class="card h-100">
 <div class="card-body">
      </div>
      <div class="card-footer">
      </div>
    </div>-->

    <tr class="border-0">
      <th scope="row" class="border-0"></th>
      <td  class="table-success border-0" style=text-align:center;> <h5 class="card-title">Estudiantes</h5></td>
      <td  class="table-warning border-0" style=text-align:center;><h5 class="card-title">Socios</h5></td>
      <td  class="table-info border-0" style=text-align:center;><h5 class="card-title">Visitas</h5></td>
    </tr>
    <tr>
      <th scope="row" class="border-0"></th>
      <td  class="table-success" style=text-align:center;> <p class="card-text">Tienen un descuento <br> 80%</p></td>
      <td  class="table-warning" style=text-align:center;><p class="card-text">Tienen un descuento <br> 50%</p></td>
      <td  class="table-info" style=text-align:center;><p class="card-text">Tienen un descuento <br> 15%</p></td>
    </tr>
    <tr>
      <th scope="row" class="border-0"></th>
      <td  class="table-success" style=text-align:center;> <small class="text-muted">* presentar documentación</small></td>
      <td  class="table-warning" style=text-align:center;><small class="text-muted">* presentar documentación</small></td>
      <td  class="table-info" style=text-align:center;><small class="text-muted">* presentar documentación</small></td>
    </tr>
  </tbody>
</table>
  
</div>





<body>
<link rel="stylesheet" href="css/ticket.css">
    





  
<br>

</body>